// var BABYSITTERDATA = $.get('http://localhost:3000/test-data.json');

var BABYSITTERDATA = {       
        "afsjiosk": {
            "image": "json_images/eric-schultheis.jpg",
            "first-name": "Eric",
            "last-name": "Schultheiss",
            "address": "30 Leslie Street NE",
            "zip-code": "30307",
            "email-address": "ebates92@gmail.com",
            "password": "SuperH@rdP@ssw0rd",
            "birthdate":"09/02/1988",
            "gender":"male",
            "max-children":"3",
            "hourly-rate": "15",
            "miles-willing":"25",
            "age-group": "0 - 6 months, 7 months - 3 years",
            "description": "children are the seed of all evil and must be cleansed.",
            "education":"mind your own business.",
            "school-name": "Hogwarts",
            "paid-experience": "2-3",
            "languages": "english",
            "transportation": "yes",
            "availability": {
                "morning": {
                    "0":"yes",
                    "1":"yes",
                    "2":"yes",
                    "3":"yes",
                    "4":"yes",
                    "5":"yes",
                    "6":"yes"
                },
                "afternoon": {
                    "0":"yes",
                    "1":"yes",
                    "2":"yes",
                    "3":"yes",
                    "4":"yes",
                    "5":"yes",
                    "6":"yes"
                },
                "evening": {
                    "0":"yes",
                    "1":"yes",
                    "2":"yes",
                    "3":"yes",
                    "4":"yes",
                    "5":"yes",
                    "6":"yes"
                },
                "overnight": {
                    "0":"yes",
                    "1":"yes",
                    "2":"yes",
                    "3":"yes",
                    "4":"yes",
                    "5":"yes",
                    "6":"yes"
                }
            },
            "smoke":"no",
            "pets":"yes",
            "cats":"yes",
            "dogs":"no"
        },
        "adslfkjo": {
            "image": "json_images/good-babysitter.jpg",
            "first-name": "Good",
            "last-name": "Schultheiss",
            "address": "30 Leslie Street NE",
            "zip-code": "30307",
            "email-address": "ebates92@gmail.com",
            "password": "SuperH@rdP@ssw0rd",
            "birthdate":"09/02/1988",
            "gender":"male",
            "max-children":"3",
            "hourly-rate": "15",
            "miles-willing":"25",
            "age-group": "0 - 6 months, 7 months - 3 years",
            "description": "children are the seed of all evil and must be cleansed.",
            "education":"mind your own business.",
            "school-name": "Hogwarts",
            "paid-experience": "2-3",
            "languages": "english",
            "transportation": "yes",
            "availability": {
                "morning": {
                    "0":"yes",
                    "1":"yes",
                    "2":"yes",
                    "3":"yes",
                    "4":"yes",
                    "5":"yes",
                    "6":"yes"
                },
                "afternoon": {
                    "0":"yes",
                    "1":"yes",
                    "2":"yes",
                    "3":"yes",
                    "4":"yes",
                    "5":"yes",
                    "6":"yes"
                },
                "evening": {
                    "0":"yes",
                    "1":"yes",
                    "2":"yes",
                    "3":"yes",
                    "4":"yes",
                    "5":"yes",
                    "6":"yes"
                },
                "overnight": {
                    "0":"yes",
                    "1":"yes",
                    "2":"yes",
                    "3":"yes",
                    "4":"yes",
                    "5":"yes",
                    "6":"yes"
                }
            },
            "smoke":"no",
            "pets":"yes",
            "cats":"yes",
            "dogs":"no"
        },
        "asdfjopl": {
            "image": "json_images/grumpy-cat.jpeg",
            "first-name": "Cat",
            "last-name": "Schultheiss",
            "address": "30 Leslie Street NE",
            "zip-code": "30307",
            "email-address": "ebates92@gmail.com",
            "password": "SuperH@rdP@ssw0rd",
            "birthdate":"09/02/1988",
            "gender":"male",
            "max-children":"3",
            "hourly-rate": "15",
            "miles-willing":"25",
            "age-group": "0 - 6 months, 7 months - 3 years",
            "description": "children are the seed of all evil and must be cleansed.",
            "education":"mind your own business.",
            "school-name": "Hogwarts",
            "paid-experience": "2-3",
            "languages": "english",
            "transportation": "yes",
            "availability": {
                "morning": {
                    "0":"yes",
                    "1":"yes",
                    "2":"yes",
                    "3":"yes",
                    "4":"yes",
                    "5":"yes",
                    "6":"yes"
                },
                "afternoon": {
                    "0":"yes",
                    "1":"yes",
                    "2":"yes",
                    "3":"yes",
                    "4":"yes",
                    "5":"yes",
                    "6":"yes"
                },
                "evening": {
                    "0":"yes",
                    "1":"yes",
                    "2":"yes",
                    "3":"yes",
                    "4":"yes",
                    "5":"yes",
                    "6":"yes"
                },
                "overnight": {
                    "0":"yes",
                    "1":"yes",
                    "2":"yes",
                    "3":"yes",
                    "4":"yes",
                    "5":"yes",
                    "6":"yes"
                }
            },
            "smoke":"no",
            "pets":"yes",
            "cats":"yes",
            "dogs":"no"
        },
        "dknvoals": {
            "image": "json_images/kyle-brauer.jpg",
            "first-name": "Kyle",
            "last-name": "Schultheiss",
            "address": "30 Leslie Street NE",
            "zip-code": "30307",
            "email-address": "ebates92@gmail.com",
            "password": "SuperH@rdP@ssw0rd",
            "birthdate":"09/02/1988",
            "gender":"male",
            "max-children":"3",
            "hourly-rate": "15",
            "miles-willing":"25",
            "age-group": "0 - 6 months, 7 months - 3 years",
            "description": "children are the seed of all evil and must be cleansed.",
            "education":"mind your own business.",
            "school-name": "Hogwarts",
            "paid-experience": "2-3",
            "languages": "english",
            "transportation": "yes",
            "availability": {
                "morning": {
                    "0":"yes",
                    "1":"yes",
                    "2":"yes",
                    "3":"yes",
                    "4":"yes",
                    "5":"yes",
                    "6":"yes"
                },
                "afternoon": {
                    "0":"yes",
                    "1":"yes",
                    "2":"yes",
                    "3":"yes",
                    "4":"yes",
                    "5":"yes",
                    "6":"yes"
                },
                "evening": {
                    "0":"yes",
                    "1":"yes",
                    "2":"yes",
                    "3":"yes",
                    "4":"yes",
                    "5":"yes",
                    "6":"yes"
                },
                "overnight": {
                    "0":"yes",
                    "1":"yes",
                    "2":"yes",
                    "3":"yes",
                    "4":"yes",
                    "5":"yes",
                    "6":"yes"
                }
            },
            "smoke":"no",
            "pets":"yes",
            "cats":"yes",
            "dogs":"no"
        },
        "sqeroiuu": {
            "image": "json_images/mj-baby.jpeg",
            "first-name": "MJ",
            "last-name": "Schultheiss",
            "address": "30 Leslie Street NE",
            "zip-code": "30307",
            "email-address": "ebates92@gmail.com",
            "password": "SuperH@rdP@ssw0rd",
            "birthdate":"09/02/1988",
            "gender":"male",
            "max-children":"3",
            "hourly-rate": "15",
            "miles-willing":"25",
            "age-group": "0 - 6 months, 7 months - 3 years",
            "description": "children are the seed of all evil and must be cleansed.",
            "education":"mind your own business.",
            "school-name": "Hogwarts",
            "paid-experience": "2-3",
            "languages": "english",
            "transportation": "yes",
            "availability": {
                "morning": {
                    "0":"yes",
                    "1":"yes",
                    "2":"yes",
                    "3":"yes",
                    "4":"yes",
                    "5":"yes",
                    "6":"yes"
                },
                "afternoon": {
                    "0":"yes",
                    "1":"yes",
                    "2":"yes",
                    "3":"yes",
                    "4":"yes",
                    "5":"yes",
                    "6":"yes"
                },
                "evening": {
                    "0":"yes",
                    "1":"yes",
                    "2":"yes",
                    "3":"yes",
                    "4":"yes",
                    "5":"yes",
                    "6":"yes"
                },
                "overnight": {
                    "0":"yes",
                    "1":"yes",
                    "2":"yes",
                    "3":"yes",
                    "4":"yes",
                    "5":"yes",
                    "6":"yes"
                }
            },
            "smoke":"no",
            "pets":"yes",
            "cats":"yes",
            "dogs":"no"
        }
    }

var BABYSITTERIDS = Object.keys(BABYSITTERDATA);


// creates swipe container
function bodyContainer () {
    // random babysitter selected
    var babySitterId = grabBabysitters();

    // swipe container

        // if making a second container, needs to be at -1 z-index
    var mainBoxArray = document.querySelectorAll(".main-box")
    if (mainBoxArray[0]) {
        var $container = $('<div>', {
            'class': 'main-box behind',
            'id': babySitterId
        });
    } else {
        var $container = $('<div>', {
            'class': 'main-box',
            'id': babySitterId
        });
    };


    // anchor tag for image to sit in
    var $anchor = $('<a>', {
        href: ""
    });

    // swipe image
    var $image = $('<img>', {
        'src': BABYSITTERDATA[babySitterId]["image"]
    });

    // swipe description
    var $babysitterDescription = $('<div>', {
        'class':'babysitter-description'
    })
        .append(`<p class=name>Name: ${BABYSITTERDATA[babySitterId]['first-name']}</p>`)
        .append(`<p class=hourly-rate>$${BABYSITTERDATA[babySitterId]['hourly-rate']}/hour</p>`);
    
    // append elements
    $('body').append(
        ($container)
            .append(($anchor)
                .append($image)
            )
            .append($babysitterDescription)
        );    
};

// looks through database for random image
function grabBabysitters () {
    var random = Math.floor((Math.random() * BABYSITTERIDS.length));
    return BABYSITTERIDS[random];
}

// swipe functionality

function swipeLeftRight () {
    var mainBoxArray = document.querySelectorAll(".main-box");
    var swipeCard = mainBoxArray[0];
    var primaryStart;
    // adds touch start event
    swipeCard.addEventListener("touchstart", function(startEvent) {
        event.preventDefault();
        var startArray = startEvent.targetTouches;
        primaryStart = startArray.item(0);
        // track movement of touch across the screen
        swipeCard.addEventListener('touchmove', function(moveEvent){
            event.preventDefault();
            console.log(moveEvent);
            var moveArray = moveEvent.changedTouches;
            var primaryMove = moveArray[0];
            var distanceMovedX = primaryMove.screenX - primaryStart.screenX;
            swipeCard.style.left = distanceMovedX + 'px';
        });
    });
    // adds touchend event and determines the distance traveled across x coordinate to determine swipe ressult
    swipeCard.addEventListener("touchend", function(endEvent) {
        event.preventDefault();
        var endArray = endEvent.changedTouches;
        var primaryEnd = endArray.item(0);
        var requiredDistance = 80;
        var distanceMovedX = primaryEnd.screenX - primaryStart.screenX;
        console.log(distanceMovedX);
        // determines if necessary distance traveled is met
        if (requiredDistance < distanceMovedX) {
            console.log("true");
            reloadSwipe();
        } else if (-requiredDistance > distanceMovedX) {
            console.log('false');
            reloadSwipe();
        } else {
            console.log('reswipe');
            var mainBoxArray = document.querySelectorAll(".main-box");
            var swipeCard = mainBoxArray[0];
            var windowSize = window.screen.width;
            swipeCard.style.left = (windowSize/2);
        };
    });
};

function removeSwipeCard () {
    var mainBoxArray = document.querySelectorAll(".main-box");
    var swipeCard = mainBoxArray[0];
    document.querySelector('body').removeChild(swipeCard);
};

function reloadSwipe() {
    removeSwipeCard();
    // remove behind class  REFACTOR AT SOME POINT
    document.querySelector(".main-box").classList.remove('behind');
    bodyContainer();
    swipeLeftRight();
};

  
bodyContainer();
bodyContainer();
swipeLeftRight();